function Y = Wstd(X)
% Copyright (c) 2015, MathWorks, Inc.
    Y = std(X,[],2);
end