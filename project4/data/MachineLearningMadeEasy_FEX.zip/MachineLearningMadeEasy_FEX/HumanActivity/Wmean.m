function Y = Wmean(X)
% Copyright (c) 2015, MathWorks, Inc.
    Y = mean(X,2);
end